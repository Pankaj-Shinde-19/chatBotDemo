package com.luv2code.springboot.cruddemo.dtos;

public class Name {
    public String original;

    // Add getters and setters for the above field
}

