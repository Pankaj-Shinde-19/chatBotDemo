package com.luv2code.springboot.cruddemo.dtos;

public class FulfillmentResponse {
    private Messages fulfillment_response;

    public Messages getFulfillment_response() {
        return fulfillment_response;
    }

    public void setFulfillment_response(Messages fulfillment_response) {
        this.fulfillment_response = fulfillment_response;
    }
}
