package com.luv2code.springboot.cruddemo.dtos;

public class Message {
    private Text text;

    public Text getText() {
        return text;
    }

    public void setText(Text text) {
        this.text = text;
    }
}
